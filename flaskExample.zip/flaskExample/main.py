# import statements
from flask import Flask, request, render_template

# creates the application
app = Flask(__name__)


# renders mai.html and passes some values to it
@app.route('/')
def home():
    # string to send to main.html
    a = "Jeremy"
    # can also send lists to print out or do things with
    list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    return render_template('home.html', name=a, numbers=list)   # name is the variable to be used in the html file

@app.route('/send_data_to_flask', methods=['POST', 'GET'])
def get_data():
    # get data from submission on html page.
    # 'text' is the name of the input field on the html page
    text = request.form['text']
    print text
    # if the user did not enter anything reload the home template
    if text == '':
        return home()
    # else render a page where the text is displayed
    else:
        return text

# if the app exists, run that junk
if __name__ == "__main__":
    app.run()